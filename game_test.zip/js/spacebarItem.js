class SpacebarItem
{
    constructor()
    {
        this.item = "";
        this.chargeHeight = 70;
        this.chargeRate = 0;
        this.charge = 0;
    }
}